/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wm.api.call;

import angularapi.Transaction;
import com.System.Profile;
import com.System.Wget;
import com.login.Util;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author Saksham
 */
public class Wallet_Transaction extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Connection con = null;
        Statement st = null;
        ResultSet rs;
        //   String username = String.valueOf(request.getParameter("username"));
        //   String Response = String.valueOf(request.getParameter("Response"));
        System.out.println(43);
        try {

            con = Util.getConnection();
            st = con.createStatement();
            HttpSession session = request.getSession();
            String username = String.valueOf(session.getAttribute("username")).trim();
            String toAddress = String.valueOf(request.getParameter("toAddress"));
            String amount = String.valueOf(request.getParameter("amount"));
            long am = Long.parseLong(amount);
            // Wget w = new Wget();

            //out.print(a1);
            String query = "";

            query = "select * from register where username=?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, username);//1 specifies the first parameter in the query i.e. name  

            System.out.println(stmt);
            rs = stmt.executeQuery();
            // Profile r1 = new Profile();
            // Wallet_Transaction a1 = new Wallet_Transaction();
            String wallet_id = null;
            String password = null;
            String imobicash_address = null;
            while (rs.next()) {

                //a1.name = rs.getString("name");
                wallet_id = rs.getString("wallet_id");
                password = rs.getString("wallet_password");
                imobicash_address = rs.getString("imobicash_address");
            }
            System.out.println("responseStatus:");
            String url = Util.COINHOST + "/operator/wallets";
            URL obj = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("password", "" + password + "");
            // con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            // String password = "Welcome To Saksham App Thankyou";//String.valueOf(request.getParameter("password"));
            System.out.println("password:" + password);
            String body = "{\"fromAddress\": \"" + imobicash_address + "\", \"toAddress\": \"" + toAddress + "\",\"amount\":\"" + am + "\", \"changeAddress\": \"" + imobicash_address + "\"}";

            //"{\"password\": \"Welcome To Saksham App Thankyou\"}";//String.valueOf(request.getParameter("password"));
            // System.out.println("urlParameters:" + urlParameters);
            conn.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(conn.getOutputStream());
            wr.writeBytes(body);
            wr.flush();
            wr.close();
            //System.out.println("responsecon:" + con);
            // out.println("responsecon:" + con);
            int responseCode = conn.getResponseCode();
            System.out.println("responseStatus:" + responseCode);
            //out.println("responseStatus:" + responseCode);
            String responseStatus = conn.getResponseMessage();
            System.out.println("responseStatus:" + responseStatus);
            //out.println("responseStatus:" + responseStatus);
            BufferedReader in = new BufferedReader(new InputStreamReader(
                    conn.getInputStream()));
            //System.out.println("response68"+con.getInputStream());
            //out.println("response69"+con.getInputStream());
            String inputLine;
            StringBuffer resp = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                //System.out.println("response73");
                // out.println("response74");
                // System.out.println("response:" + resp);
                //  out.println("response:" + resp);
                resp.append(inputLine);
            }
            in.close();
            // out.println("response78");
            System.out.println("response:" + resp.toString());
            String output = resp.toString();
            JSONObject json = new JSONObject(output);
            String id = json.getString("id");
            System.out.println("response:" + id);
            // return resp.toString();
            genWallet s = new genWallet();
            //s.genAddress(password, id);
            out.println(s.genAddress(password, id));

        } catch (IOException e) {
            System.out.println("error" + e.getMessage());
        } catch (JSONException ex) {
            Logger.getLogger(genWallet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            Logger.getLogger(Wallet_Transaction.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    public String name, email, wallet_id, imobicash_address, password;
    public long balance;
}
