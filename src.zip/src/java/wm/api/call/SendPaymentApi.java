/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wm.api.call;

import com.login.Util;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author susheel
 */
public class SendPaymentApi extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String fromAddress = request.getParameter("fromAddress");
        String toAddress = request.getParameter("toAddress");
        String cr = request.getParameter("amount");

        Connection con = null;
        ResultSet rs;
        String wallet_id="" ,wallet_password="";
        try {
            con = Util.getConnection();
            Statement st = con.createStatement();
            String query = "select wallet_id ,wallet_password from register where username=? and password=?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, username);//1 specifies the first parameter in the query i.e. name  
            stmt.setString(2, password);
            System.out.println(stmt);
            rs = stmt.executeQuery();
            if(rs.next()){
                wallet_id=rs.getString("wallet_id");
                wallet_password=rs.getString("wallet_password");
            String url = "http://149.28.199.86:3001/operator/wallets/" + wallet_id + "/transactions";
            URL obj = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("password", "" + wallet_password + "");
            // con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            // String password = "Welcome To Saksham App Thankyou";//String.valueOf(request.getParameter("password"));
            //System.out.println("password:" + password);
            String body = "{\"fromAddress\": \"" + fromAddress + "\", \"toAddress\": \"" + toAddress + "\",\"amount\":\"" + cr + "\", \"changeAddress\": \"" + fromAddress + "\"}";

            //"{\"password\": \"Welcome To Saksham App Thankyou\"}";//String.valueOf(request.getParameter("password"));
            // System.out.println("urlParameters:" + urlParameters);
            conn.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(conn.getOutputStream());
            wr.writeBytes(body);
            wr.flush();
            wr.close();
            int responseCode = conn.getResponseCode();
            System.out.println("responseStatus:" + responseCode);
            //out.println("responseStatus:" + responseCode);
            String responseStatus = conn.getResponseMessage();
            System.out.println("responseStatus:" + responseStatus);
            //out.println("responseStatus:" + responseStatus);
            BufferedReader in = new BufferedReader(new InputStreamReader(
                    conn.getInputStream()));
            //System.out.println("response68"+con.getInputStream());
            //out.println("response69"+con.getInputStream());
            String inputLine;
            StringBuffer resp = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                //System.out.println("response73");
                // out.println("response74");
                // System.out.println("response:" + resp);
                //  out.println("response:" + resp);
                resp.append(inputLine);
            }
            in.close();
            // out.println("response78");
            System.out.println("response:" + resp.toString());
            String output = resp.toString();
            out.println(output);
            }
        } catch (Exception e) {
             out.println(e.getMessage());

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
