/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wm.api.call;

import com.login.Util;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author Saksham
 */
public class WalletBalance {

    public String Balance(String id) {

        try {
            // System.out.println("pwd:"+pwd);
            System.out.println("id:" + id);
            System.out.println("responseStatus:");
            String url = Util.COINHOST + "/operator/" + id + "/balance";
            // String password = "This is Mala from India";
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("Accept", "application/json");
            con.setRequestProperty("Content-Type", "application/json");

            // con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            String encodedUrl = null;
            //request.getParameter("password");
            // System.out.println(password);
            // encodedUrl = URLEncoder.encode(password, "UTF-8");
            // System.out.println(encodedUrl);
            // String body = "{\"password\": \""+encodedUrl+"\"}";//String.valueOf(request.getParameter("password"));
            // System.out.println("urlParameters:" + urlParameters);
            con.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
            // wr.writeBytes(password);
            //wr.flush();
            //wr.close();
            //System.out.println("responsecon:" + con);
            // out.println("responsecon:" + con);
            int responseCode = con.getResponseCode();
            System.out.println("responseStatus:" + responseCode);
            //out.println("responseStatus:" + responseCode);
            String responseStatus = con.getResponseMessage();
            System.out.println("responseStatus:" + responseStatus);
            //out.println("responseStatus:" + responseStatus);
            BufferedReader in = new BufferedReader(new InputStreamReader(
                    con.getInputStream()));
            //System.out.println("response68"+con.getInputStream());
            //out.println("response69"+con.getInputStream());
            String inputLine;
            StringBuffer resp = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                //System.out.println("response73");
                // out.println("response74");
                // System.out.println("response:" + resp);
                //  out.println("response:" + resp);
                resp.append(inputLine);
            }
            in.close();
            // out.println("response78");
            System.out.println("response:" + resp.toString());
//String output = resp.toString();
//JSONObject json = new JSONObject(output);
//String address= json.getString("address");
            return resp.toString();

            //out.println("response:" + resp.toString());
        } catch (IOException e) {
            System.out.println("error" + e.getMessage());
        }
        return null;
    }

}
