/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wm.api.call;

import angularapi.AllUser;
import angularapi.getTransactionHashes;
import com.System.Wget;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.login.Util;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Saksham
 */
public class blocks extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        try {
            Wget w = new Wget();
            /// String h = w.wget("http://149.28.199.86:3001/blockchain/blocks");

            JSONArray jsonArray = new JSONArray(w.wget( Util.COINHOST +"/blockchain/blocks"));
            //iterate loop

            ArrayList<blocks> a1 = new ArrayList<>();

            for (int i = 0; i < jsonArray.length(); i++) {
                blocks a = new blocks();
                //get the JSON Object 
                JSONObject obj = jsonArray.getJSONObject(i);

                   
                         
                    //    String previoushash = obj.getString("previousHash");
                     //   String hash = obj.getString("hash");
                        
                        
                //   String index = obj.getString("index");
                a.previoushash = obj.getString("previousHash");
                a.hash = obj.getString("hash");
                a1.add(a);
            }
           
            Gson gson = new Gson();
            String messages = gson.toJson(a1);
            out.println(messages);

        } catch (Exception e) {
            out.println("{\"Error\": \"True\" ,\"Message\": \"Failed\" }");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    public String m, addr, previoushash, hash, index, timestamp;

}
