/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wm.api.call;

import com.login.Util;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author Saksham
 */
public class genWallet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("application/json;charset=UTF-8");
         PrintWriter out = response.getWriter();
         try {
            System.out.println("responseStatus:");
            String url = Util.COINHOST + "/operator/wallets";
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Accept", "application/json");
            con.setRequestProperty("Content-Type", "application/json");
          // con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
          String password ="Welcome To Saksham App Thankyou";//String.valueOf(request.getParameter("password"));
            System.out.println("password:"+password);
          String body = "{\"password\": \"Welcome To Saksham App Thankyou\"}";//String.valueOf(request.getParameter("password"));
           // System.out.println("urlParameters:" + urlParameters);
            con.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
            wr.writeBytes(body);
            wr.flush();
            wr.close();
            //System.out.println("responsecon:" + con);
           // out.println("responsecon:" + con);
            int responseCode = con.getResponseCode();
           System.out.println("responseStatus:" + responseCode);
            //out.println("responseStatus:" + responseCode);
            String responseStatus = con.getResponseMessage();
        System.out.println("responseStatus:" + responseStatus);
          //out.println("responseStatus:" + responseStatus);
            BufferedReader in = new BufferedReader(new InputStreamReader(
                    con.getInputStream()));
            //System.out.println("response68"+con.getInputStream());
            //out.println("response69"+con.getInputStream());
            String inputLine;
           StringBuffer resp = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                //System.out.println("response73");
               // out.println("response74");
                // System.out.println("response:" + resp);
               //  out.println("response:" + resp);
                resp.append(inputLine);
            }
            in.close();
           // out.println("response78");
           System.out.println("response:" + resp.toString());
String output = resp.toString();
JSONObject json = new JSONObject(output);
String id= json.getString("id");
System.out.println("response:" +id);
           // return resp.toString();
           genWallet s = new genWallet();
                  //s.genAddress(password, id);
           out.println(s.genAddress(password, id));

            }
        catch (IOException e) {
            System.out.println("error" + e.getMessage());
        } catch (JSONException ex) {
            Logger.getLogger(genWallet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
 public String genretegenWallet(String pwd) {
       // response.setContentType("application/json;charset=UTF-8");
        // PrintWriter out = response.getWriter();
         try {
            System.out.println("responseStatus:");
            String url = "http://149.28.199.86:3001/operator/wallets";
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Accept", "application/json");
            con.setRequestProperty("Content-Type", "application/json");
          // con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
          String password =pwd;//String.valueOf(request.getParameter("password"));
            System.out.println("password:"+password);
          String body = "{\"password\": \""+password+"\"}";//String.valueOf(request.getParameter("password"));
           // System.out.println("urlParameters:" + urlParameters);
            con.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
            wr.writeBytes(body);
            wr.flush();
            wr.close();
            //System.out.println("responsecon:" + con);
           // out.println("responsecon:" + con);
            int responseCode = con.getResponseCode();
           System.out.println("responseStatus:" + responseCode);
            //out.println("responseStatus:" + responseCode);
            String responseStatus = con.getResponseMessage();
        System.out.println("responseStatus:" + responseStatus);
          //out.println("responseStatus:" + responseStatus);
            BufferedReader in = new BufferedReader(new InputStreamReader(
                    con.getInputStream()));
            //System.out.println("response68"+con.getInputStream());
            //out.println("response69"+con.getInputStream());
            String inputLine;
           StringBuffer resp = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                //System.out.println("response73");
               // out.println("response74");
                // System.out.println("response:" + resp);
               //  out.println("response:" + resp);
                resp.append(inputLine);
            }
            in.close();
           // out.println("response78");
           System.out.println("response:" + resp.toString());
String output = resp.toString();
JSONObject json = new JSONObject(output);
String id= json.getString("id");
System.out.println("response:" +id);
           // return resp.toString();
           genWallet s = new genWallet();
                  String result = s.genAddress(password, id);
                  
           System.out.println(result);
          String res="{\"id\": \""+id+"\",\"result\": \""+result+"\"}";
    System.out.println(res);
          return res;
            }
        catch (IOException e) {
            System.out.println("error" + e.getMessage());
        } catch (JSONException ex) {
            Logger.getLogger(genWallet.class.getName()).log(Level.SEVERE, null, ex);
        }
         return null;
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
public String genAddress(String pwd,String id) {
       
        try {
             System.out.println("pwd:"+pwd);
              System.out.println("id:"+id);
          System.out.println("responseStatus:");
            String url = "http://149.28.199.86:3001/operator/wallets/"+id+"/addresses";
           // String password = "This is Mala from India";
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Accept", "application/json");
            con.setRequestProperty("Content-Type", "application/json;charset=utf-8");
            con.setRequestProperty("password", ""+pwd+"");
            // con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            String encodedUrl = null;
            //request.getParameter("password");
           // System.out.println(password);
            // encodedUrl = URLEncoder.encode(password, "UTF-8");
            // System.out.println(encodedUrl);
            // String body = "{\"password\": \""+encodedUrl+"\"}";//String.valueOf(request.getParameter("password"));
            // System.out.println("urlParameters:" + urlParameters);
            con.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
            // wr.writeBytes(password);
            //wr.flush();
            //wr.close();
            //System.out.println("responsecon:" + con);
            // out.println("responsecon:" + con);
            int responseCode = con.getResponseCode();
            System.out.println("responseStatus:" + responseCode);
            //out.println("responseStatus:" + responseCode);
            String responseStatus = con.getResponseMessage();
            System.out.println("responseStatus:" + responseStatus);
            //out.println("responseStatus:" + responseStatus);
            BufferedReader in = new BufferedReader(new InputStreamReader(
                    con.getInputStream()));
            //System.out.println("response68"+con.getInputStream());
            //out.println("response69"+con.getInputStream());
            String inputLine;
            StringBuffer resp = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                //System.out.println("response73");
                // out.println("response74");
                // System.out.println("response:" + resp);
                //  out.println("response:" + resp);
                resp.append(inputLine);
            }
            in.close();
           // out.println("response78");
            System.out.println("response:" + resp.toString());
String output = resp.toString();
JSONObject json = new JSONObject(output);
String address= json.getString("address");
            return address;
            
            //out.println("response:" + resp.toString());

            }
        catch (IOException e) {
            System.out.println("error" + e.getMessage());
        } catch (JSONException ex) {
            Logger.getLogger(genWallet.class.getName()).log(Level.SEVERE, null, ex);
        }
       return null;
    }

}
