/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package angularapi;

import com.System.Wget;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.login.Util;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author mala singh
 */
public class Transaction extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Connection con = null;
        Statement st = null;
        ResultSet rs;
        String Ether_Address = null;
        String SendTransaction;
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");
        try {
            con = Util.getConnection();
            st = con.createStatement();

            String query = "";
            query = "select * from register where username='asdf12@g.c'";

            System.out.println(query);
            rs = st.executeQuery(query);
            Transaction a1 = new Transaction();
            while (rs.next()) {
                a1.imobicash_address = rs.getString("imobicash_address");
                a1.username = rs.getString("username");
                 a1.wallet_id = rs.getString("wallet_id");
                 a1.wallet_password = rs.getString("wallet_password");
                
                //a1.balance=a1;
            }
            Gson gson = new GsonBuilder().create();
            String jsonArray = gson.toJson(a1);
            //out.println(messages); 
            out.write(jsonArray);

            //["Hi","Hello","How r u?"]
            //   out.println(messages);
            con.close();
        } catch (Exception e) {
            out.println(e);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        PrintWriter out = response.getWriter();
        Connection con = null;
        try {

            System.out.println(38888);
            System.out.println(41);
            ResultSet rs;
            int i = 0;
            BufferedReader br = new BufferedReader(
                    new InputStreamReader(request.getInputStream()));
            String json = "";
            if (br != null) {
                json = br.readLine();
            }
            System.out.println(json);

            JSONObject jsonObj = new JSONObject(json);
            con = Util.getConnection();
            Statement st = con.createStatement();
            HttpSession session = request.getSession();
            String username = (String) session.getAttribute("username");
            
            
            
            String toAddress = jsonObj.getString("imobicash_receiver");
            String wallet_id = jsonObj.getString("wallet_id");
            String wallet_password = jsonObj.getString("wallet_password");
            
                        //String ether_sender = "FYpNGhBAKXwPVQiAgdzu1N1Nd9vLBNNEh6AWrpkP53MT2izxLjM9MRD7PGqabKuonZgC37mtfHp3D8nXrDYzDfLEHehQb6x";//jsonObj.getString("imobicash_address");

          //  String ether_sender = "FXfsRXC3VM3iWkTTiCqRtWV4vqF1zEuzUVxLcGKHQDTwYwUteBZsd2HbUpuSBTA2jTcmudvaRgU3JTSSpGWt3DG6UavZj1e";
           String fromAddress = jsonObj.getString("imobicash_address");
            int cr = jsonObj.getInt("cr");
            /*Wget w = new Wget();
            String a = w.wget("http://localhost:8089/sendTransactionbytecoin?fromadd=" + ether_sender + "&amount=" + cr + "&to=" + ether_receiver + "");
            System.out.println(a);*/
            String url = "http://149.28.199.86:3001/operator/wallets/"+wallet_id+"/transactions";
            URL obj = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("password", ""+wallet_password+"");
            // con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
           // String password = "Welcome To Saksham App Thankyou";//String.valueOf(request.getParameter("password"));
            //System.out.println("password:" + password);
            String body ="{\"fromAddress\": \""+fromAddress+"\", \"toAddress\": \""+toAddress+"\",\"amount\":\""+cr+"\", \"changeAddress\": \""+fromAddress+"\"}" ;
                    
                    //"{\"password\": \"Welcome To Saksham App Thankyou\"}";//String.valueOf(request.getParameter("password"));
            // System.out.println("urlParameters:" + urlParameters);
            conn.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(conn.getOutputStream());
            wr.writeBytes(body);
            wr.flush();
            wr.close();
            //System.out.println("responsecon:" + con);
            // out.println("responsecon:" + con);
            int responseCode = conn.getResponseCode();
            System.out.println("responseStatus:" + responseCode);
            //out.println("responseStatus:" + responseCode);
            String responseStatus = conn.getResponseMessage();
            System.out.println("responseStatus:" + responseStatus);
            //out.println("responseStatus:" + responseStatus);
            BufferedReader in = new BufferedReader(new InputStreamReader(
                    conn.getInputStream()));
            //System.out.println("response68"+con.getInputStream());
            //out.println("response69"+con.getInputStream());
            String inputLine;
            StringBuffer resp = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                //System.out.println("response73");
                // out.println("response74");
                // System.out.println("response:" + resp);
                //  out.println("response:" + resp);
                resp.append(inputLine);
            }
            in.close();
            // out.println("response78");
            System.out.println("response:" + resp.toString());
            String output = resp.toString();
            JSONObject json1 = new JSONObject(output);
            //JSONObject jsonObj1 = new JSONObject(a);
            try {
                
                String a1 = json1.getString("hash");
                System.out.println(66);

                System.out.println(a1);
               
                if (a1 != null) {
                    String q = "insert into transactions(username,description,imobicash_sender,imobicash_receiver,wallet_password,wallet_id,cr,TransactionHash)"
                            + " values (?,?,?,?,?,?,?,?)";
                    PreparedStatement stmt = con.prepareStatement(q);
            System.out.println(stmt);
            stmt.setString(1, username);//1 specifies the first parameter in the query i.e. name  
            stmt.setString(2, "Wallet Transaction");
            stmt.setString(3, fromAddress);
            stmt.setString(4, toAddress);
            stmt.setString(5, wallet_password);
            stmt.setString(6, wallet_id);
            stmt.setInt(7, cr);
            stmt.setString(8, a1);
           
                    
                    System.out.println(q);

                    i = stmt.executeUpdate(q, Statement.RETURN_GENERATED_KEYS);
                    out.println("{\"Error\": \"False\" ,\"Message\": \"success\" }");
                } else {
                    out.print("{\"Error\": \"True\" ,\"Message\": \"failed\" }");
                }
            } catch (Exception e) {
                String msg=e.getMessage();
                out.print("{\"Error\": \"True\" ,\"Message\": \"" + msg + "\" }");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Transaction.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JSONException ex) {
            Logger.getLogger(Transaction.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            Logger.getLogger(Transaction.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    public String username, imobicash_address,wallet_id,wallet_password;
}
